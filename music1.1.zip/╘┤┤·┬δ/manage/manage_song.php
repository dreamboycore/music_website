<?php
$select=$_POST["select"];
include "../connect.sql.php";

if($select==1)
{
if(!empty($_POST["artist_id"])&&!empty($_POST["song_name"])&&
    !empty($_POST["album_id"])&&!empty($_POST["sort"])&&
    !empty($_POST["served"])&&!empty($_POST["language"])){
$artist_id=$_POST["artist_id"];
$song_name=$_POST["song_name"];
$album_id=$_POST["album_id"];
$sort=$_POST["sort"];
$served=$_POST["served"];
$language=$_POST["language"];
$sql="SELECT MAX(song_id) A FROM song";
$res=mysqli_query($connect,$sql);
$row_num=mysqli_num_rows($res);
if($row_num!=0) {
for($a=1;$a<=$row_num;$a++){
$row_assoc=mysqli_fetch_assoc($res);
$song_id=$row_assoc['A']+1;
$sql_write="INSERT INTO song (song_id,artist_id,song_name,album_id,sort,served,language,hot) 
VALUES ($song_id,$artist_id,'$song_name',$album_id,$sort,$served,$language,0)";
$res=mysqli_query($connect,$sql_write);
if($res){
    $audio_folder=intval(($song_id-1)/100)+1;
    $file=$_FILES["file"];
    move_uploaded_file($file['tmp_name'],"../audio/".$audio_folder."/".$song_id.".mp3");
    header("location:../manage.php");
}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}}}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

elseif($select==2)
{
if(!empty($_POST["song_id"])&&!empty($_POST["artist_id"])&&
    !empty($_POST["song_name"])&&!empty($_POST["album_id"])&&
    !empty($_POST["sort"])&&!empty($_POST["served"])&&
    !empty($_POST["language"])){
$song_id=$_POST["song_id"];
$artist_id=$_POST["artist_id"];
$song_name=$_POST["song_name"];
$album_id=$_POST["album_id"];
$sort=$_POST["sort"];
$served=$_POST["served"];
$language=$_POST["language"];
$sql_write="UPDATE song SET artist_id='$artist_id',song_name='$song_name',album_id='$album_id',sort='$sort',served='$served',language='$language' WHERE song_id='$song_id'";
$res=mysqli_query($connect,$sql_write);
if($res){header("location:../manage.php");}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

elseif($select==3)
{
if(!empty($_POST["song_id"])){
$song_id=$_POST["song_id"];
$sql_write="DELETE FROM song WHERE song_id='$song_id'";
$res=mysqli_query($connect,$sql_write);
if($res){
    $audio_folder=intval(($song_id-1)/100)+1;
    $file="../audio/".$audio_folder."/".$song_id.".mp3";
    unlink($file);
    header("location:../manage.php");
}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

else{echo '<script language="JavaScript">;alert("错误");location.href="../manage.php";</script>';}




mysqli_close($connect);

?>