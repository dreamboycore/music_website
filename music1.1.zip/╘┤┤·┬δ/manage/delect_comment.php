<?php
session_start();

include "../connect.sql.php";
$comment_id=$_POST["comment_id"];
if(!empty($_SESSION["num"]))
{
$sql_write="DELETE FROM comment WHERE num='$comment_id'";
$res=mysqli_query($connect,$sql_write);
if($res)
{
    header("location:../manage.php");
}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}
else{echo '<script language="JavaScript">;alert("错误");location.href="../manage.php";</script>';}

mysqli_close($connect);

?>