<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="https://www.layuicdn.com/layui/css/layui.css">
    <link href="css/css.css" rel="stylesheet" type="text/css" >
    <link href="https://src.axui.cn/src/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?>    

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">
    
<div class="layui-row layui-col-space20">
    <div class="layui-col-sm8 layui-col-md8 layui-col-lg8">
	    <div class="layui-row layui-col-space10">
            <?php
            include "connect.sql.php";
            $song_id=$_GET['id'];
            $sql = "SELECT s.song_name,a.artist_name,a.artist_id,al.album_id,al.album_name,s.served 
	        FROM song s,artist a,album al 
	        where song_id='$song_id' AND s.artist_id=a.artist_id AND al.album_id=s.album_id";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
	        $song_name=$row_assoc['song_name'];
            $artist_name=$row_assoc['artist_name'];
            $artist_id=$row_assoc['artist_id'];
            $album_name=$row_assoc['album_name'];
            $served=$row_assoc['served'];
            $album_id=$row_assoc['album_id'];
            $cover_folder=intval(($album_id-1)/100)+1;
            $audio_folder=intval(($song_id-1)/100)+1;
            echo '
            <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
            <div style="text-align:center">
            <img width="200" height="200" src="cover/'.$cover_folder.'/'.$album_id.'.jpg">
            </div>
            </div>

	        <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
	        <h2>单曲：'.$song_name.'</h2><br>
	        歌手：<a href="artist.php?id='.$artist_id.'">'.$artist_name.'</a><br>                          
	        所属专辑：<a href="album.php?id='.$album_id.'">'.$album_name.'</a><br><br><br>
	        <button class="layui-btn layui-btn-warm layui-btn-sm" href="##" id="id-'.$song_id.'">加入</button>
	        <button class="layui-btn layui-btn-danger layui-btn-sm" name="hot" value="'.$song_id.'">点赞</button>
	        ';
	        if(!empty($_SESSION['num']))
            {
            if(($_SESSION['permission']==1)||($_SESSION['permission']==2&&$served==2))
            {
            echo '<button class="layui-btn layui-btn-sm"><a href="audio/'.$audio_folder.'/'.$song_id.'.mp3" download="'.$artist_name.' - '.$song_name.'.mp3">下载</a></button>';
            }
            else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
            }
            else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
	        echo '
	        </div>
	        ';
	        }
	        }
	        mysqli_close($connect);
	        ?>                

	        <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
		        <hr class="layui-bg-red">
	        </div>

	        <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
		        <?php 
		        $id=$_GET['id'];
		        echo '
		        <form class="layui-form" action="comment/comment_song.php?id='.$id.'" method="post">';
		        ?>
			        <div class="layui-form-item layui-form-text">
				        <label class="layui-form-label">评论</label>
				        <div class="layui-input-block">
					        <textarea placeholder="请输入内容" class="layui-textarea" name="str" lay-search required  lay-verify="required"></textarea>
				        </div>
			        </div>
			        <div class="layui-form-item">
				        <div class="layui-input-block">
					        <button type="submit" class="layui-btn" lay-submit="" lay-filter="demo1">发送</button>
					        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
				        </div>
			        </div>
		        </form>
            </div>

            <?php
            include "connect.sql.php";
            $song_id=$_GET['id'];
            $sql = "SELECT c.time,u.permission,u.num,u.name,comment 
	        FROM comment c,usertable u,song s 
	        where c.song_id='$song_id' and c.user_num=u.num and c.song_id=s.song_id";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            echo '
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
			<div class="ax-comment">
			<div class="ax-break-line"></div>
            '; 
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $time=$row_assoc['time'];
            $permission=$row_assoc['permission'];
            $num=$row_assoc['num'];
            $name=$row_assoc['name'];
            $comment=$row_assoc['comment'];
            echo '
			<div class="ax-item">
			<a href="##" class="ax-avatar" style="background-image: url(user/'.$num.'.jpg)"></a>
		    <div class="ax-text">
			<div class="ax-row01 ax-row">
			<div class="ax-col">
			<a href="##" class="ax-name">'.$name.'</a>
			<span class="ax-badge ax-badge-border ax-badge-primary">
            ';
            if($permission==1){echo '管理员';}
            elseif($permission==2){echo '使用用户';}
            else{echo '';}
            echo '
			</span>
			</div>
			<i class="ax-floor">'.$i.'楼</i>
			</div>
			<div class="ax-row02">
		    <span>'.$comment.'</span>
			</div>
			<div class="ax-row03 ax-row">
			<div class="ax-col">
			<span class="ax-time">'.$time.'</span>
			</div>
			</div>
		    </div>
			</div>
			<div class="ax-break-line"></div>                                                     
            ';
            }
			echo '	
			</div>
            </div>
            ';
            }
            mysqli_close($connect);
	        ?>
		</div>
	</div>

    <div class="layui-col-sm4 layui-col-md4 layui-col-lg4">
        <h2>推荐单曲</h2>
        <hr class="layui-bg-red">
        <?php
        $song_id=$_GET['id'];
        include "connect.sql.php";
        $sql = "SELECT * FROM song s,artist a WHERE song_id!='$song_id' AND s.artist_id=a.artist_id ORDER BY hot DESC";
        $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
        $row_num=mysqli_num_rows($res);
        if($row_num!=0)
        {
        if($row_num>10){$row_num=10;}
        for($i=1;$i<=$row_num;$i++)
        {
        $row_assoc=mysqli_fetch_assoc($res);
        $song_id=$row_assoc['song_id'];
        $artist_id=$row_assoc['artist_id'];
        $song_name=$row_assoc['song_name'];
        $artist_name=$row_assoc['artist_name'];
        echo '
        <a href="song.php?id='.$song_id.'" class="ax-ell">'.$song_name.'</a><br>
        <a href="artist.php?id='.$artist_id.'" class="ax-color-ignore ax-ell">'.$artist_name.'</a>
        ';
        if($i==10){echo '<hr class="layui-bg-red">';}
        else{echo '<hr>';}
        }
        }
        mysqli_close($connect);
        ?>
    </div>
</div>

</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="https://www.layuicdn.com/layui/layui.js"></script>
<script src="https://src.axui.cn/src/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/js/ax.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/plugins/aplayer/js/APlayer.min.js"></script>

<?php include "player.php";?>

<?php include "js.php"; ?>

</body> 
</html> 