<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="https://www.layuicdn.com/layui/css/layui.css">
    <link href="css/css.css" rel="stylesheet" type="text/css" >
    <link href="https://src.axui.cn/src/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?>

<?php

if(!empty($_SESSION["permission"])){}
else{echo '<script language="JavaScript">;alert("未登录");location.href="index.php";</script>';}
?>

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">

<?php
if(!empty($_SESSION['num']))
{
if($_SESSION['permission']==1){include 'manage_master.php';}
elseif($_SESSION['permission']==2){include 'manage_user.php';}
else{;}
}
?>
</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="https://www.layuicdn.com/layui/layui.js"></script>
<script src="https://src.axui.cn/src/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/js/ax.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/plugins/aplayer/js/APlayer.min.js"></script>

<?php include "js.php"; ?>

<?php include "player.php";?>

</body> 
</html> 