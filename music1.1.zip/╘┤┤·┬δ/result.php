<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="https://www.layuicdn.com/layui/css/layui.css">
    <link href="css/css.css" rel="stylesheet" type="text/css" >
    <link href="https://src.axui.cn/src/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?> 

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">

<table class="layui-table" lay-size="sm" style="margin: 0 auto;">
    <colgroup>
    <col>
    <col>
    <col>
    <col width="200">
    </colgroup>
    <thead>
    <tr>
    <th>排名</th>
    <th>标题</th>
    <th>歌手</th>
    <th>选项</th>
    </tr> 
    </thead>
    <tbody>
<?php
include "connect.sql.php";
$select=$_GET['select'];
$str=$_GET['str'];
if($select==1)
{$sql = "SELECT s.song_id,s.song_name,a.artist_name,a.artist_id,s.served 
FROM song s,artist a
where s.song_name LIKE '%".$str."%' AND s.artist_id=a.artist_id";}
if($select==2)
{$sql = "SELECT s.song_id,s.song_name,a.artist_name,a.artist_id,s.served 
FROM song s,artist a,album al
WHERE al.album_name LIKE '%".$str."%' AND s.artist_id=a.artist_id AND s.album_id=al.album_id";}
if($select==3)
{$sql = "SELECT song_id,song_name,artist_name,artist_id,served 
FROM
(SELECT s.song_id,s.song_name,a.artist_name,a.artist_id,s.served 
FROM song s,artist a WHERE a.artist_name LIKE '%".$str."%' AND s.artist_id=a.artist_id
UNION 
SELECT s.song_id,s.song_name,a2.artist_name,a2.artist_id,s.served 
FROM song s,artist a1,artist a2,album al 
WHERE a1.artist_name LIKE '%".$str."%' AND al.releaser_id=a1.artist_id AND al.album_id=s.album_id AND a2.artist_id=s.artist_id) A";}
$res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
$row_num=mysqli_num_rows($res);
if($row_num!=0) {
if($row_num>10){$row_num=10;}
for($i=1;$i<=$row_num;$i++) {
$row_assoc=mysqli_fetch_assoc($res);
$song_id=$row_assoc['song_id'];$song_name=$row_assoc['song_name'];
$artist_id=$row_assoc['artist_id'];$artist_name=$row_assoc['artist_name'];
$served=$row_assoc['served'];$audio_folder=intval(($song_id-1)/100)+1;
echo '<tr>
<td>'.$i.'</td>
<td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
<td><a href="artist.php?id='.$artist_id.'">'.$artist_name.'</a></td><td>
<button class="layui-btn layui-btn-warm layui-btn-sm" href="##" id="id-'.$song_id.'">加入</button>
<button class="layui-btn layui-btn-danger layui-btn-sm" name="hot" value="'.$song_id.'">点赞</button>
';
if(!empty($_SESSION['num'])){
if(($_SESSION['permission']==1)||($_SESSION['permission']==2&&$served==2)){
echo '<button class="layui-btn layui-btn-sm"><a href="audio/'.$audio_folder.'/'.$song_id.'.mp3" download="'.$artist_name.' - '.$song_name.'.mp3">下载</a></button>';}
else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}}
else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
echo '
</td>
</tr>
';}}
mysqli_close($connect);
        ?>
    </tbody>
</table>   
 


</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="https://www.layuicdn.com/layui/layui.js"></script>
<script src="https://src.axui.cn/src/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/js/ax.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/plugins/aplayer/js/APlayer.min.js"></script>

<?php include "player.php";?>

<?php include "js.php"; ?>

</body> 
</html> 