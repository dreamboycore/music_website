<script>
layui.use('element', function() {var element = layui.element;});
</script>

<script type='text/javascript'>
$(document).ready(function () {
    $("#menu01").axMenu({
        row:true,
    });
});
</script>

<script>
layui.use('form', function(){
    var form = layui.form;
});
</script>

<script type="text/javascript">
    $("#open-win00").click(function () {
        $("#win00").addClass("ax-window-show");
    });
    $("#open-win01").click(function () {
        $("#win01").addClass("ax-window-show");
    });
    $("#open-win02").click(function () {
        $("#win02").addClass("ax-window-show");
    });
</script>

<script>
function loadXMLDoc()
{
	var xmlhttp;
	if (window.XMLHttpRequest)
	{
		//  IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
		xmlhttp=new XMLHttpRequest();
	}
	else
	{
		// IE6, IE5 浏览器执行代码
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function()
	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
		{
			document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
		}
	}
	xmlhttp.open("GET","js/table.php",true);
	xmlhttp.send();
}
</script>