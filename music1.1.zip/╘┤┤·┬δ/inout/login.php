<?php 

session_start();//启用session

$url=isset($_SERVER['HTTP_REFERER']);
if($url=="")
{
	header("location:../index.php");
	exit;
}
include "../connect.sql.php";
$id=$_POST['id'];
$pw=$_POST['pw'];
$sql="SELECT * FROM usertable WHERE id='$id' AND pw='$pw'";
$res=mysqli_query($connect,$sql);
$row=mysqli_num_rows($res);//获取查询的行数
if($row!=0){
	$row_assoc=mysqli_fetch_assoc($res);
	$num=$row_assoc['num'];
	$permission=$row_assoc['permission'];
	$name=$row_assoc['name'];
	$id=$row_assoc['id'];
	if(!$permission==0){
		$_SESSION["num"] = $num;
		$_SESSION["id"] = $id;
		$_SESSION["permission"] = $permission;
		$_SESSION["name"] = $name;
		$_SESSION["play_song"]=array();
		$_SESSION["play_num"]=0;
		header("location:../index.php");		
	}else{
		echo "<script>alert('账号封禁中！')</script>";
		echo '<meta http-equiv="refresh" content="2.0;url=../index.php">';
	}	
}else{
	echo "<script>alert('用户名或密码错误！')</script>";
	echo '<meta http-equiv="refresh" content="2.0;url=../index.php">';
}

mysqli_close($connect);

?>