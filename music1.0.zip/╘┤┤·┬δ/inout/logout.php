<?php
session_start();
$url=isset($_SERVER['HTTP_REFERER']);
if($url=="")
{
	header("location:../index.php");
	exit;
}

if(!empty($_SESSION["permission"]))
{
	unset($_SESSION["num"]);
	unset($_SESSION["id"]);
	unset($_SESSION["permission"]);
	unset($_SESSION["name"]);
	unset($_SESSION["play_song"]);
	unset($_SESSION["play_num"]);
	header("location:../index.php");	
}

else
{
	echo "<script>alert('没有缓存或未登录！')</script>";
	echo '<meta http-equiv="refresh" content="2.0;url=../index.php">';
}
?>

