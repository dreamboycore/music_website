<?php

$id=$_POST['id'];
$pw=$_POST['pw'];
$name=$_POST['name'];

include "../connect.sql.php";
$sql="SELECT * FROM usertable WHERE id='$id'";
$res=mysqli_query($connect,$sql);
$row=mysqli_num_rows($res);//获取查询的行数
if($row!=0) 
{
	echo "<script>alert('账号已存在！')</script>";
	echo '<meta http-equiv="refresh" content="2.0;url=../index.php">';
}
else
{
	$user_match="SELECT * FROM usertable";
    $match=mysqli_query($connect,$user_match);
    $match_num=mysqli_num_rows($match)+1;
    $sql="INSERT INTO usertable (num,id,pw,permission,name) VALUE ($match_num,'$id','$pw',2,'$name')";
    $res=mysqli_query($connect,$sql);
    if($res)
    {
        $file=$_FILES["file"];
        move_uploaded_file($file['tmp_name'],"../user/".$match_num.".jpg");
        header("location:../index.php");
    }
}

mysqli_close($connect);

?>