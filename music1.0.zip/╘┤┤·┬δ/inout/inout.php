<?php
session_start();
date_default_timezone_set('PRC'); //调整时区。

if(!empty($_SESSION["permission"]))
{
echo '
<li class="layui-nav-item"><a href="##" id="open-win00">播放列表管理</a></li>
<li class="layui-nav-item">
<a href="javascript:;"><img src="user/'.$_SESSION["num"].'.jpg" class="layui-nav-img">'.$_SESSION["name"].'</a>
<dl class="layui-nav-child">
<dd><a href="manage.php">管理中心</a></dd>
<dd>
<form action="inout/logout.php" method="post">
<a href="javascript:void(0);" onclick="javascript:document.forms[0].submit();">退出登录</a>
</form>
</dd>	
</dl>
</li>
';
}
else
{
echo '<li class="layui-nav-item"><a href="##" id="open-win00">播放列表管理</a></li>';
echo '<li class="layui-nav-item"><a href="##" id="open-win01">登录</a></li>';
echo '<li class="layui-nav-item"><a href="##" id="open-win02">注册</a></li>';
}
?>