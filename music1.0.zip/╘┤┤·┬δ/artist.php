<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="layui/css/layui.css">
    <link href="axui/css/ax.css" rel="stylesheet" type="text/css" >
    <link href="axui/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?>    

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">

<div class="layui-row layui-col-space20">
    <div class="layui-col-sm8 layui-col-md8 layui-col-lg8">
        <div class="layui-row layui-col-space10">
            <?php
            include "connect.sql.php";
            $artist_id=$_GET['id'];
            $sql = "SELECT al.album_id,a.artist_name,a.description,a.country,a.type
            from artist a,album al
            where al.releaser_id='$artist_id' AND al.releaser_id=a.artist_id 
            GROUP BY al.releaser_id
            ORDER BY al.time DESC";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $album_id=$row_assoc['album_id'];
            $artist_name=$row_assoc['artist_name'];
            $description=$row_assoc['description'];
            $country=$row_assoc['country'];
            $type=$row_assoc['type'];
            $cover_folder=intval(($album_id-1)/100)+1;
            echo '
            <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
            <div style="text-align:center">
            <img width="200" height="200" src="cover/'.$cover_folder.'/'.$album_id.'.jpg">
            </div>
            </div>

            <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
            <h2>歌手：'.$artist_name.'</h2><br>
            国籍：'.$country.'<br>
            类别：'.$type.'<br><br><br><br>
            </div>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
            个人介绍：<br>'.$description.'
            </div>
            ';
            }
            }
            else
            {
            $sql = "SELECT al.album_id,a.artist_name,a.description,a.country,a.type
            from artist a,album al,song s
            where s.artist_id='$artist_id' AND al.album_id=s.album_id AND a.artist_id=s.artist_id
            GROUP BY s.artist_id
            ORDER BY al.time DESC";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $album_id=$row_assoc['album_id'];
            $artist_name=$row_assoc['artist_name'];
            $description=$row_assoc['description'];
            $country=$row_assoc['country'];
            $type=$row_assoc['type'];
            $cover_folder=intval(($album_id-1)/100)+1;
            echo '
            <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
            <div style="text-align:center">
            <img width="200" height="200" src="cover/'.$cover_folder.'/'.$album_id.'.jpg">
            </div>
            </div>
    
            <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
            <h2>歌手：'.$artist_name.'</h2><br>
            国籍：'.$country.'<br>
            类别：'.$type.'<br><br><br><br>
            </div>
    
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
            个人介绍：<br>'.$description.'
            </div>
            ';
            }
            }
            }
            mysqli_close($connect);
            ?>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <hr class="layui-bg-green">
            </div>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                热门前10首：
                <table class="layui-table" lay-size="sm" style="margin: 0 auto;">
                    <colgroup>
                    <col>
                    <col>
                    <col>
                    <col width="200">
                    </colgroup>
                    <thead>
                    <tr>
                    <th>序号</th>
                    <th>标题</th>
                    <th>专辑</th>
                    <th>选项</th>
                    </tr> 
                    </thead>
                    <tbody>
                    <?php
                    include "connect.sql.php";
                    $artist_id=$_GET['id'];
                    $sql = "SELECT song_id,song_name,album_id,album_name,artist_name,served FROM
                    (SELECT s.song_id,s.song_name,al.album_id,al.album_name,a.artist_name,s.served,s.hot
                    FROM song s,artist a,album al WHERE s.artist_id='$artist_id' AND s.artist_id=a.artist_id AND al.album_id=s.album_id
                    UNION
                    SELECT s.song_id,s.song_name,al.album_id,al.album_name,a2.artist_name,s.served,s.hot
                    FROM song s,artist a1,artist a2,album al WHERE al.releaser_id='$artist_id' AND al.releaser_id=a1.artist_id AND al.album_id=s.album_id AND a2.artist_id=s.artist_id) A
                    ORDER BY hot DESC";
                    $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
                    $row_num=mysqli_num_rows($res);
                    if($row_num!=0)
                    {
                    for($i=1;$i<=$row_num;$i++)
                    {
                    $row_assoc=mysqli_fetch_assoc($res);
                    $song_id=$row_assoc["song_id"];
                    $song_name=$row_assoc["song_name"];
                    $album_id=$row_assoc["album_id"];
                    $album_name=$row_assoc['album_name'];
                    $artist_name=$row_assoc['artist_name'];
                    $served=$row_assoc['served'];
                    $audio_folder=intval(($song_id-1)/100)+1;
                    echo '
                    <tr>
                    <td>'.$i.'</td>
                    <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
                    <td><a href="album.php?id='.$album_id.'">'.$album_name.'</a></td>
                    <td>
                    <button class="layui-btn layui-btn-warm layui-btn-sm" href="##" id="id-'.$song_id.'">加入</button>
                    <button class="layui-btn layui-btn-danger layui-btn-sm" name="hot" value="'.$song_id.'">点赞</button>
                    ';
                    if(!empty($_SESSION['num']))
                    {
                    if(($_SESSION['permission']==1)||($_SESSION['permission']==2&&$served==2))
                    {
                    echo '<button class="layui-btn layui-btn-sm"><a href="audio/'.$audio_folder.'/'.$song_id.'.mp3" download="'.$artist_name.' - '.$song_name.'.mp3">下载</a></button>';
                    }
                    else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
                    }
                    else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
                    echo '
                    </td>
                    </tr>
                    ';
                    }
                    }
                    mysqli_close($connect);
                    ?>                
                    </tbody>
                </table> 
            </div>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <hr class="layui-bg-red">
            </div>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                所有专辑：
                <div class="layui-row layui-col-space20">
                    <?php
                    $artist_id=$_GET['id'];
                    include "connect.sql.php";
                    $sql="SELECT al.album_name,al.album_id 
                    FROM album al,artist a 
                    WHERE al.releaser_id='$artist_id' AND al.releaser_id=a.artist_id
                    ORDER BY time DESC";
                    $res=mysqli_query($connect,$sql);
                    $row_num=mysqli_num_rows($res);/*获取查询的行数*/
                    if($row_num!=0)
                    {
                    for($i=1;$i<=$row_num;$i++)
                    {
                    $row_assoc=mysqli_fetch_assoc($res);
                    $album_name=$row_assoc['album_name'];
                    $album_id=$row_assoc['album_id'];
                    $cover_folder=intval(($album_id-1)/100)+1;
                    echo '
                    <div class="layui-col-sm6 layui-col-md4 layui-col-lg3">
                    <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                    <a href="album.php?id='.$album_id.'">
                    <div style="background-color:#eeeeee;text-align:center;">
                    <div style="padding:10px">
                    <img src="cover/'.$cover_folder.'/'.$album_id.'.jpg" style="height:auto;width:80%;">
                    </div>
                    <button title="'.$album_name.'" class="layui-btn layui-btn-fluid " style="background-color:#eeeeee;">
                    <a href="album.php?id='.$album_id.'" class="ax-ell">'.$album_name.'</a>
                    </button>
                    </div>
                    </a>
                    </div>
                    </div>
                    ';
                    }
                    }
                    mysqli_close($connect);
                    ?>
                </div>    
            </div>
        </div>
    </div>

    <div class="layui-col-sm4 layui-col-md4 layui-col-lg4">
        <h2>推荐歌手</h2>
        <hr class="layui-bg-red">
        <?php
        $artist_id=$_GET['id'];
        include "connect.sql.php";
        $sql = "SELECT artist_id,artist_name FROM
        (SELECT s.song_id,a.artist_id,a.artist_name,s.hot
        FROM song s,artist a,album al WHERE s.artist_id=a.artist_id AND al.album_id=s.album_id
        UNION
        SELECT s.song_id,a.artist_id,a.artist_name,s.hot
        FROM song s,artist a,album al WHERE al.releaser_id=a.artist_id AND al.album_id=s.album_id) A
        WHERE artist_id!='$artist_id'
        GROUP BY artist_id
        ORDER BY SUM(hot) DESC";
        $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
        $row_num=mysqli_num_rows($res);
        if($row_num!=0)
        {
        if($row_num>10){$row_num=10;}
        for($i=1;$i<=$row_num;$i++)
        {
        $row_assoc=mysqli_fetch_assoc($res);
        $artist_id=$row_assoc['artist_id'];
        $artist_name=$row_assoc["artist_name"];
        echo '
        <a href="artist.php?id='.$artist_id.'" class="ax-ell">'.$artist_name.'</a>
        ';
        if($i==10){echo '<hr class="layui-bg-red">';}
        else{echo '<hr>';}
        }
        }
        mysqli_close($connect);
        ?>
    </div>
</div>

</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="layui/layui.js"></script>
<script src="axui/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="axui/js/ax.min.js" type="text/javascript"></script>
<script src="axui/APlayer.min.js"></script>

<?php include "player.php";?>

<?php include "js.php"; ?>

</body> 
</html> 