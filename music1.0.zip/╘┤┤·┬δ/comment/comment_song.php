<?php
session_start();
date_default_timezone_set('PRC'); //调整时区。

$song_id=$_GET['id'];
$str=$_POST['str'];
if($str==NULL){echo '<script language="JavaScript">;alert("评论不能是空的");location.href="../song.php?id='.$song_id.'";</script>';}
if(!empty($_SESSION["permission"])){
$user_id=$_SESSION["num"];
include "../connect.sql.php";
$user_match="SELECT MAX(num) A FROM comment";
$match=mysqli_query($connect,$user_match);
$row_assoc=mysqli_fetch_assoc($match);
$match_num=$row_assoc['A']+1;
$sql="INSERT INTO comment (num,song_id,album_id,user_num,time,comment) VALUE ($match_num,$song_id,0,$user_id,NOW(),'$str')";
$res=mysqli_query($connect,$sql);
if($res){header("location:../song.php?id=$song_id");}
mysqli_close($connect);
}
echo '<script language="JavaScript">;alert("未登录");location.href="../song.php?id='.$song_id.'";</script>';

?>