<footer style="text-align: center;color: #808080;">
    <div style="margin: 0 auto;">
        <div style="text-align: center;padding: 44px 0;">
            <div style="margin: 0 14px;">
                <a href="http://www.dreamboycore-official.com" target="_blank">开发者的个人网页</a>
            </div>
        </div>
    </div>
</footer>