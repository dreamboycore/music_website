<?php
session_start();//启用session
include "../connect.sql.php";
$song_id=$_GET['song_id'];
if(!empty($_SESSION["permission"]))
{
$sql = "SELECT * FROM song WHERE song_id='$song_id'";
$res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
$row_num=mysqli_num_rows($res);
if($row_num!=0)
{
for($i=1;$i<=$row_num;$i++)
{
$row_assoc=mysqli_fetch_assoc($res);
$hot=$row_assoc["hot"]+1;
$sql = "UPDATE song SET hot='$hot' WHERE song_id='$song_id'";
$res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
}
}
}
else{echo "<script>alert('错误');</script>";}
mysqli_close($connect);
?>