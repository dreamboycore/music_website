
<?php
session_start();//启用session
  if(!empty($_SESSION["permission"])) {$_SESSION["play_song"]=[];$_SESSION["play_num"]=0;}  
    ?>