<div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
    <ul class="layui-tab-title">
    <li class="layui-this">评论管理</li>
    </ul>
    <div class="layui-tab-content">

        <div class="layui-tab-item layui-show">
            <?php
            include "connect.sql.php";
            if(!empty($_SESSION['num']))
            {
            $user_num=$_SESSION['num'];
            $sql = "SELECT c.time,c.song_id,u.permission,u.num,u.name,comment,s.song_name,c.num
	        FROM comment c,usertable u,song s
	        where u.num='$user_num' and c.user_num=u.num and c.song_id=s.song_id";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            echo '
		    <div class="ax-comment">
		    <div class="ax-break-line"></div>
            '; 
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $comment_num=$row_assoc['num'];
            $song_id=$row_assoc['song_id'];
            $song_name=$row_assoc['song_name'];
            $time=$row_assoc['time'];
            $permission=$row_assoc['permission'];
            $num=$row_assoc['num'];
            $name=$row_assoc['name'];
            $comment=$row_assoc['comment'];
            echo '
		    <div class="ax-item">
		    <a href="##" class="ax-avatar" style="background-image: url(user/'.$user_num.'.jpg)"></a>
		    <div class="ax-text">
		    <div class="ax-row01 ax-row">
		    <div class="ax-col">
		    <a href="##" class="ax-name">'.$name.'</a>
		    </div>
		    </div>
		    <div class="ax-row02">
		    <span>'.$comment.'</span>
		    </div>
		    <div class="ax-row03 ax-row">
            <div class="ax-col">
            <span class="ax-time">'.$time.'<a href="song.php?id='.$song_id.'" class="ax-action ax-action-good">From 歌曲 '.$song_name.'</a></span>
            </div>
            <form action="manage/delect_comment.php" method="post">
            <button class="layui-btn layui-btn-danger layui-btn-sm" name="comment_id" value="'.$comment_num.'">删除</button>
            </form>
            </div>
		    </div>
		    </div>
		    <div class="ax-break-line"></div>                                                     
            ';
            }
		    echo '	
		    </div>
            ';
            }
            }
            mysqli_close($connect);
	        ?>

            <?php
            include "connect.sql.php";
            if(!empty($_SESSION['num']))
            {
            $user_num=$_SESSION['num'];
            $sql = "SELECT c.time,c.album_id,u.permission,u.num,u.name,comment,al.album_name,c.num
	        FROM comment c,usertable u,album al
	        where u.num='$user_num' and c.user_num=u.num and c.album_id=al.album_id";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            echo '
			<div class="ax-comment">
			<div class="ax-break-line"></div>
            '; 
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $comment_num=$row_assoc['num'];
            $album_id=$row_assoc['album_id'];
            $album_name=$row_assoc['album_name'];
            $time=$row_assoc['time'];
            $permission=$row_assoc['permission'];
            $num=$row_assoc['num'];
            $name=$row_assoc['name'];
            $comment=$row_assoc['comment'];
            echo '
			<div class="ax-item">
			<a href="##" class="ax-avatar" style="background-image: url(user/'.$user_num.'.jpg)"></a>
		    <div class="ax-text">
			<div class="ax-row01 ax-row">
			<div class="ax-col">
			<a href="##" class="ax-name">'.$name.'</a>
			</div>
			</div>
			<div class="ax-row02">
		    <span>'.$comment.'</span>
			</div>
			<div class="ax-row03 ax-row">
            <div class="ax-col">
            <span class="ax-time">'.$time.'<a href="album.php?id='.$album_id.'" class="ax-action ax-action-good">From 专辑 '.$album_name.'</a></span>
            </div>
            <form action="manage/delect_comment.php" method="post">
            <button class="layui-btn layui-btn-danger layui-btn-sm" name="comment_id" value="'.$comment_num.'">删除</button>
            </form>
            </div>
		    </div>
			</div>
			<div class="ax-break-line"></div>                                                     
            ';
            }
			echo '	
			</div>
            ';
            }
            }
            mysqli_close($connect);
	        ?>
        </div>

    </div>
</div>