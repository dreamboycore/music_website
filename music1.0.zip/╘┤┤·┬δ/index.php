<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="https://www.layuicdn.com/layui/css/layui.css">
    <link href="css/css.css" rel="stylesheet" type="text/css" >
    <link href="https://src.axui.cn/src/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?>

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">

<div class="layui-row layui-col-space20">
    <div class="layui-col-sm8 layui-col-md8 layui-col-lg8">
        <div class="layui-row layui-col-space10">
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <div class="layui-row">
                    <div class="layui-col-sm6 layui-col-md6 layui-col-lg6"><h2>新歌速递</h2></div>
                    <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
                        <div style="text-align:right"><a href="topist.php">查看更多</a></div>
                    </div>
                    <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                        <table class="layui-table" lay-size="sm" style="margin: 0 auto;">
                            <colgroup>
                            <col><col><col><col width="200">
                            </colgroup>
                            <thead>
                            <tr>
                            <th>排名</th>
                            <th>标题</th>
                            <th>歌手</th>
                            <th>选项</th>
                            </tr> 
                            </thead>
                            <tbody>
                            <?php
                            include "connect.sql.php";
                            $sql = "SELECT s.song_id,s.song_name,a.artist_name,s.served,s.artist_id,s.album_id
                            FROM song s,artist a
                            WHERE s.artist_id=a.artist_id
                            ORDER BY s.song_id DESC";
                            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
                            $row_num=mysqli_num_rows($res);
                            if($row_num!=0)
                            {
                            if($row_num>5){$row_num=5;}
                            for($i=1;$i<=$row_num;$i++)
                            {
                            $row_assoc=mysqli_fetch_assoc($res);
                            $song_id=$row_assoc['song_id'];
                            $song_name=$row_assoc['song_name'];
                            $artist_name=$row_assoc['artist_name'];
                            $served=$row_assoc['served'];
                            $artist_id=$row_assoc['artist_id'];
                            $album_id=$row_assoc['album_id'];
                            $audio_folder=intval(($song_id-1)/100)+1;
                            echo '
                            <tr>
                            <td>'.$i.'</td>
                            <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
                            <td><a href="artist.php?id='.$artist_id.'">'.$artist_name.'</a></td>
                            <td>
                            <button class="layui-btn layui-btn-warm layui-btn-sm" href="##" id="id-'.$song_id.'">加入</button>
                            <button class="layui-btn layui-btn-danger layui-btn-sm" name="hot" value="'.$song_id.'">点赞</button>
                            ';
                            if(!empty($_SESSION['num']))
                            {
                            if(($_SESSION['permission']==1)||($_SESSION['permission']==2&&$served==2))
                            {
                            echo '<button class="layui-btn layui-btn-sm"><a href="audio/'.$audio_folder.'/'.$song_id.'.mp3" download="'.$artist_name.' - '.$song_name.'.mp3">下载</a></button>';
                            }
                            else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
                            }
                            else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
                            echo '
                            </td>
                            </tr>
                            ';
                            }
                            }
                            mysqli_close($connect);
                            ?>
                            <tr><td colspan="4"><div style="text-align:center"><a href="topist.php">查看更多</a></div></td></tr>
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <hr class="layui-bg-red">
            </div>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <div class="layui-row">
                    <div class="layui-col-sm6 layui-col-md6 layui-col-lg6"><h2>新专速递</h2></div>
                    <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
                        <div style="text-align:right"><a href="search.php">查看更多</a></div>
                    </div> 
                    <div class="layui-col-sm12 layui-col-md12 layui-col-lg12"> 
                        <div class="layui-row layui-col-space20">
                            <?php
                            include "connect.sql.php";
                            $sql="SELECT album_name,album_id FROM album ORDER BY album_id DESC";
                            $res=mysqli_query($connect,$sql);
                            $row_num=mysqli_num_rows($res);/*获取查询的行数*/
                            if($row_num!=0)
                            {
                            if($row_num>4){$row_num=4;}
                            for($i=1;$i<=$row_num;$i++)
                            {
                            $row_assoc=mysqli_fetch_assoc($res);
                            $album_name=$row_assoc['album_name'];
                            $album_id=$row_assoc['album_id'];
                            $cover_folder=intval(($album_id-1)/100)+1;
                            echo '
                            <div class="layui-col-sm6 layui-col-md4 layui-col-lg3">
                            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                            <a href="album.php?id='.$album_id.'">
                            <div style="background-color:#eeeeee;text-align:center;">
                            <div style="padding:10px">
                            <img src="cover/'.$cover_folder.'/'.$album_id.'.jpg" style="height:auto;width:80%;">
                            </div>
                            <button title="'.$album_name.'" class="layui-btn layui-btn-fluid " style="background-color:#eeeeee;">
                            <a href="album.php?id='.$album_id.'" class="ax-ell">'.$album_name.'</a>
                            </button>
                            </div>
                            </a>
                            </div>
                            </div>
                            ';
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
                
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <hr class="layui-bg-blue">
            </div>

            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <div class="layui-row">
                    <div class="layui-col-sm6 layui-col-md6 layui-col-lg6"><h2>热门排行榜</h2></div>
                    <div class="layui-col-sm6 layui-col-md6 layui-col-lg6">
                        <div style="text-align:right"><a href="topist.php">查看更多</a></div>
                    </div> 
                    <div class="layui-col-sm12 layui-col-md12 layui-col-lg12"> 
                        <div class="layui-row layui-col-space10">
                            <div class="layui-col-sm12 layui-col-md6 layui-col-lg4">
                                <table class="layui-table" lay-size="sm" style="margin: 0 auto;">
                                    <colgroup>
                                    <col>
                                    <col>
                                    </colgroup>
                                    <thead>
                                    <tr>
                                    <th colspan="2"><div style="text-align:center">梦音乐总榜</div></th>
                                    </tr> 
                                    <tr>
                                    <th>排名</th>
                                    <th>标题</th>
                                    </tr> 
                                    </thead>
                                    <tbody>
                                    <?php
                                    include "connect.sql.php";
                                    $sql = "SELECT song_id,song_name FROM song ORDER BY hot DESC";
                                    $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
                                    $row_num=mysqli_num_rows($res);
                                    if($row_num!=0)
                                    {
                                    if($row_num>5){$row_num=5;}
                                    for($i=1;$i<=$row_num;$i++)
                                    {
                                    $row_assoc=mysqli_fetch_assoc($res);
                                    $song_id=$row_assoc['song_id'];
                                    $song_name=$row_assoc['song_name'];
                                    echo '
                                    <tr>
                                    <td>'.$i.'</td>
                                    <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
                                    </tr>
                                    ';
                                    }
                                    }
                                    mysqli_close($connect);
                                    ?>
                                    <tr><td colspan="2"><div style="text-align:center"><a href="topist.php">查看更多</a></div></td></tr>
                                    </tbody>
                                </table> 
                            </div>

                            <div class="layui-col-sm12 layui-col-md6 layui-col-lg4">
                                <table class="layui-table" lay-size="sm" style="margin: 0 auto;">
					                <colgroup>
					                <col>
					                <col>
					                </colgroup>
					                <thead>
					                <tr>
					                <th colspan="2"><div style="text-align:center">梦音乐中国榜</div></th>
					                </tr> 
					                <tr>
					                <th>排名</th>
					                <th>标题</th>
					                </tr> 
					                </thead>
					                <tbody>
					                <?php
					                include "connect.sql.php";
					                $sql = "SELECT song_id,song_name FROM song WHERE language>=1 AND language<=4 ORDER BY hot DESC";
					                $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
					                $row_num=mysqli_num_rows($res);
					                if($row_num!=0)
					                {
					                if($row_num>5){$row_num=5;}
					                for($i=1;$i<=$row_num;$i++)
					                {
					                $row_assoc=mysqli_fetch_assoc($res);
					                $song_id=$row_assoc['song_id'];
					                $song_name=$row_assoc['song_name'];
					                echo '
					                <tr>
					                <td>'.$i.'</td>
					                <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
					                </tr>
					                ';
					                }
					                }
					                mysqli_close($connect);
					                ?>
					                <tr><td colspan="2"><div style="text-align:center"><a href="topist.php">查看更多</a></div></td></tr>
					                </tbody>
                                </table> 
                            </div>

                            <div class="layui-col-sm12 layui-col-md6 layui-col-lg4">
                                <table class="layui-table" lay-size="sm" style="margin: 0 auto;">
					                <colgroup>
					                <col>
					                <col>
					                </colgroup>
					                <thead>
					                <tr>
					                <th colspan="2"><div style="text-align:center">梦音乐国际榜</div></th>
					                </tr> 
					                <tr>
					                <th>排名</th>
					                <th>标题</th>
					                </tr> 
					                </thead>
					                <tbody>
					                <?php
					                include "connect.sql.php";
					                $sql = "SELECT song_id,song_name FROM song WHERE language>=5 AND language<=7 ORDER BY hot DESC";
					                $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
					                $row_num=mysqli_num_rows($res);
					                if($row_num!=0)
					                {
					                if($row_num>5){$row_num=5;}
					                for($i=1;$i<=$row_num;$i++)
					                {
					                $row_assoc=mysqli_fetch_assoc($res);
					                $song_id=$row_assoc['song_id'];
					                $song_name=$row_assoc['song_name'];
					                echo '
					                <tr>
					                <td>'.$i.'</td>
					                <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
					                </tr>
					                ';
					                }
					                }
					                mysqli_close($connect);
					                ?>
					                <tr><td colspan="2"><div style="text-align:center"><a href="topist.php">查看更多</a></div></td></tr>
					                </tbody>
                                </table> 
                            </div>
                    
                        </div>
                    </div> 
                
                </div>
            </div>
        </div>
    </div>

    <div class="layui-col-sm4 layui-col-md4 layui-col-lg4">
        <h2>推荐歌手</h2>
        <hr class="layui-bg-red">
        <?php
        include "connect.sql.php";
        $sql = "SELECT artist_id,artist_name FROM
        (SELECT s.song_id,a.artist_id,a.artist_name,s.hot
        FROM song s,artist a WHERE s.artist_id=a.artist_id
        UNION
        SELECT s.song_id,a.artist_id,a.artist_name,s.hot
        FROM song s,artist a,album al WHERE al.releaser_id=a.artist_id AND al.album_id=s.album_id) A 
        GROUP BY artist_id ORDER BY SUM(hot) DESC";
        $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
        $row_num=mysqli_num_rows($res);
        if($row_num!=0)
        {
        if($row_num>5){$row_num=5;}
        for($i=1;$i<=$row_num;$i++)
        {
        $row_assoc=mysqli_fetch_assoc($res);
        $artist_id=$row_assoc['artist_id'];
        $artist_name=$row_assoc["artist_name"];
        echo '
        <a href="artist.php?id='.$artist_id.'" class="ax-ell">'.$artist_name.'</a>
        ';
        if($i==5){echo '<hr class="layui-bg-red">';}
        else{echo '<hr>';}
        }
        }
        mysqli_close($connect);
        ?>

        <h2>推荐专辑</h2>
        <hr class="layui-bg-red">
        <?php
        include "connect.sql.php";
        $sql = "SELECT al.album_id,al.releaser_id,al.album_name,a.artist_name 
        from song s,album al,artist a 
        WHERE s.album_id=al.album_id 
        AND al.releaser_id=a.artist_id GROUP BY s.album_id ORDER BY SUM(hot) DESC";
        $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
        $row_num=mysqli_num_rows($res);
        if($row_num!=0)
        {
        if($row_num>5){$row_num=5;}
        for($i=1;$i<=$row_num;$i++)
        {
        $row_assoc=mysqli_fetch_assoc($res);
        $album_id=$row_assoc['album_id'];
        $releaser_id=$row_assoc["releaser_id"];
        $album_name=$row_assoc['album_name'];
        $artist_name=$row_assoc['artist_name'];
        echo '
        <a href="album.php?id='.$album_id.'" class="ax-ell">'.$album_name.'</a><br>
        <a href="artist.php?id='.$artist_id.'" class="ax-color-ignore ax-ell">'.$artist_name.'</a>
        ';
        if($i==5){echo '<hr class="layui-bg-red">';}
        else{echo '<hr>';}
        }
        }
        mysqli_close($connect);
        ?>

        <h2>推荐歌曲</h2>
        <hr class="layui-bg-red">
        <?php
        include "connect.sql.php";
        $sql = "SELECT * FROM song s,artist a WHERE s.artist_id=a.artist_id ORDER BY hot DESC";
        $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
        $row_num=mysqli_num_rows($res);
        if($row_num!=0)
        {
        if($row_num>5){$row_num=5;}
        for($i=1;$i<=$row_num;$i++)
        {
        $row_assoc=mysqli_fetch_assoc($res);
        $song_id=$row_assoc['song_id'];
        $artist_id=$row_assoc['artist_id'];
        $song_name=$row_assoc['song_name'];
        $artist_name=$row_assoc['artist_name'];
        echo '
        <a href="song.php?id='.$song_id.'" class="ax-ell">'.$song_name.'</a><br>
        <a href="artist.php?id='.$artist_id.'" class="ax-color-ignore ax-ell">'.$artist_name.'</a>
        ';
        if($i==5){echo '<hr class="layui-bg-red">';}
        else{echo '<hr>';}
        }
        }
        mysqli_close($connect);
        ?>
    </div>
</div>

</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="https://www.layuicdn.com/layui/layui.js"></script>
<script src="https://src.axui.cn/src/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/js/ax.min.js" type="text/javascript"></script>
<script src="https://src.axui.cn/src/plugins/aplayer/js/APlayer.min.js"></script>


<?php include "js.php"; ?>

<?php include "player.php";?>



</body> 
</html> 