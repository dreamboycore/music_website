<div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
    <ul class="layui-tab-title">
    <li class="layui-this">音乐上传</li>
    <li>音乐修改</li>
    <li>音乐删除</li>
    <li>新建歌手</li>
    <li>修改歌手</li>
    <li>删除歌手</li>
    <li>新建专辑</li>
    <li>修改专辑</li>
    <li>删除专辑</li>
    <li>评论管理</li>
    </ul>
    <div class="layui-tab-content">

        <div class="layui-tab-item layui-show">
            <form class="layui-form" action="manage/manage_song.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">选择歌手</label>
                    <div class="layui-input-block">
                        <select name="artist_id" lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <?php 
                            include "connect.sql.php";
                            $sql_1="SELECT * FROM artist ORDER BY artist_id ASC";
                            $res_1=mysqli_query($connect,$sql_1);
                            $row_num_1=mysqli_num_rows($res_1);/*获取查询的行数*/
                            if($row_num_1!=0)
                            {
                            for($a=1;$a<=$row_num_1;$a++)
                            {
                            $row_assoc_1=mysqli_fetch_assoc($res_1);
                            $artist_id=$row_assoc_1['artist_id'];
                            $artist_name=$row_assoc_1['artist_name'];
                            echo '<option value="'.$artist_id.'">'.$artist_name.'</option>
                            ';
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </select>
                    </div>
                </div> 
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲名</label>
                    <div class="layui-input-block">
                        <input type="text" name="song_name" placeholder="请输入标题" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">选择专辑</label>
                    <div class="layui-input-block">
                        <select name="album_id" lay-search lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <?php 
                            include "connect.sql.php";
                            $sql_1="SELECT * FROM artist ORDER BY artist_id ASC";
                            $res_1=mysqli_query($connect,$sql_1);
                            $row_num_1=mysqli_num_rows($res_1);/*获取查询的行数*/
                            if($row_num_1!=0)
                            {
                            for($a=1;$a<=$row_num_1;$a++)
                            {
                            $row_assoc_1=mysqli_fetch_assoc($res_1);
                            $artist_id=$row_assoc_1['artist_id'];
                            $artist_name=$row_assoc_1['artist_name'];
                            echo '<optgroup label="'.$artist_name.'">
                            ';
                            $sql_2="SELECT * FROM album WHERE releaser_id='$artist_id' ORDER BY album_id ASC";
                            $res_2=mysqli_query($connect,$sql_2);
                            $row_num_2=mysqli_num_rows($res_2);/*获取查询的行数*/
                            if($row_num_2!=0)
                            {
                            for($b=1;$b<=$row_num_2;$b++)
                            {
                            $row_assoc_2=mysqli_fetch_assoc($res_2);
                            $album_id=$row_assoc_2['album_id'];
                            $album_name=$row_assoc_2['album_name'];
                            echo '<option value="'.$album_id.'">'.$album_name.'</option>
                            ';
                            }
                            }
                            echo "</optgroup>
                            ";
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲序号</label>
                    <div class="layui-input-block">
                        <input type="text" name="sort" placeholder="这首歌处于专辑的位置" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">上传文件</label>
                    <div class="layui-input-block">
                        <div class="ax-form-con">
                            <div class="ax-form-input">
                                <input onmouseout="document.getElementById('file-upload2').style.display='none';" id="file-view2" type="text" lay-search required  lay-verify="required">
                                <span onmouseover="document.getElementById('file-upload2').style.display='block';" class="ax-file-btn">选择</span>
                                <input onchange="document.getElementById('file-view2').value=this.value;" id="file-upload2" class="ax-input-file" type="file" name="file" lay-search required  lay-verify="required">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">下载权限</label>
                    <div class="layui-input-block">
                        <select name="served" lay-search lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <option value="1">关闭</option>
                            <option value="2">开启</option>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲语言</label>
                    <div class="layui-input-block">
                        <input type="radio" name="language" value="1" title="国语" checked lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="2" title="闽南语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="3" title="粤语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="4" title="其他方言" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="5" title="英语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="6" title="日语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="7" title="其他语种" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="1">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_song.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲ID</label>
                    <div class="layui-input-block">
                        <input type="text" name="song_id" placeholder="请输入序号（如果是选择修改歌曲就必填）" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">选择歌手</label>
                    <div class="layui-input-block">
                        <select name="artist_id" lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <?php 
                            include "connect.sql.php";
                            $sql_1="SELECT * FROM artist ORDER BY artist_id ASC";
                            $res_1=mysqli_query($connect,$sql_1);
                            $row_num_1=mysqli_num_rows($res_1);/*获取查询的行数*/
                            if($row_num_1!=0)
                            {
                            for($a=1;$a<=$row_num_1;$a++)
                            {
                            $row_assoc_1=mysqli_fetch_assoc($res_1);
                            $artist_id=$row_assoc_1['artist_id'];
                            $artist_name=$row_assoc_1['artist_name'];
                            echo '<option value="'.$artist_id.'">'.$artist_name.'</option>
                            ';
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </select>
                    </div>
                </div> 
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲名</label>
                    <div class="layui-input-block">
                        <input type="text" name="song_name" placeholder="请输入标题" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">选择专辑</label>
                    <div class="layui-input-block">
                        <select name="album_id" lay-search lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <?php 
                            include "connect.sql.php";
                            $sql_1="SELECT * FROM artist ORDER BY artist_id ASC";
                            $res_1=mysqli_query($connect,$sql_1);
                            $row_num_1=mysqli_num_rows($res_1);/*获取查询的行数*/
                            if($row_num_1!=0)
                            {
                            for($a=1;$a<=$row_num_1;$a++)
                            {
                            $row_assoc_1=mysqli_fetch_assoc($res_1);
                            $artist_id=$row_assoc_1['artist_id'];
                            $artist_name=$row_assoc_1['artist_name'];
                            echo '<optgroup label="'.$artist_name.'">
                            ';
                            $sql_2="SELECT * FROM album WHERE releaser_id='$artist_id' ORDER BY album_id ASC";
                            $res_2=mysqli_query($connect,$sql_2);
                            $row_num_2=mysqli_num_rows($res_2);/*获取查询的行数*/
                            if($row_num_2!=0)
                            {
                            for($b=1;$b<=$row_num_2;$b++)
                            {
                            $row_assoc_2=mysqli_fetch_assoc($res_2);
                            $album_id=$row_assoc_2['album_id'];
                            $album_name=$row_assoc_2['album_name'];
                            echo '<option value="'.$album_id.'">'.$album_name.'</option>
                            ';
                            }
                            }
                            echo "</optgroup>
                            ";
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲序号</label>
                    <div class="layui-input-block">
                        <input type="text" name="sort" placeholder="这首歌处于专辑的位置" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">下载权限</label>
                    <div class="layui-input-block">
                        <select name="served" lay-search lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <option value="1">关闭</option>
                            <option value="2">开启</option>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲语言</label>
                    <div class="layui-input-block">
                        <input type="radio" name="language" value="1" title="国语" checked lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="2" title="闽南语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="3" title="粤语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="4" title="其他方言" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="5" title="英语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="6" title="日语" lay-search required  lay-verify="required">
                        <input type="radio" name="language" value="7" title="其他语种" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="2">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_song.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">歌曲ID</label>
                    <div class="layui-input-block">
                        <input type="text" name="song_id" placeholder="请输入序号（如果是选择修改歌曲就必填）" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="3">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_artist.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">歌手名</label>
                    <div class="layui-input-block">
                        <input type="text" name="artist_name" placeholder="请输入歌手名" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">国家</label>
                    <div class="layui-input-block">
                        <input type="text" name="country" placeholder="请输入国家" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">类型</label>
                    <div class="layui-input-block">
                        <input type="text" name="type" placeholder="国家+性别+类别" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">描述</label>
				    <div class="layui-input-block">
					    <textarea placeholder="请输入内容" class="layui-textarea" name="description" lay-search required  lay-verify="required"></textarea>
				    </div>
			    </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="1">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_artist.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">歌手ID</label>
                    <div class="layui-input-block">
                        <input type="text" name="artist_id" placeholder="请输入序号" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">歌手名</label>
                    <div class="layui-input-block">
                        <input type="text" name="artist_name" placeholder="请输入歌手名" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">国家</label>
                    <div class="layui-input-block">
                        <input type="text" name="country" placeholder="请输入国家" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">类型</label>
                    <div class="layui-input-block">
                        <input type="text" name="type" placeholder="国家+性别+类别" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">描述</label>
				    <div class="layui-input-block">
					    <textarea placeholder="请输入内容" class="layui-textarea" name="description" lay-search required  lay-verify="required"></textarea>
				    </div>
			    </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="2">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_artist.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">歌手ID</label>
                    <div class="layui-input-block">
                        <input type="text" name="artist_id" placeholder="请输入序号" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="3">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_album.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">专辑名</label>
                    <div class="layui-input-block">
                        <input type="text" name="album_name" placeholder="请输入标题" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">选择歌手</label>
                    <div class="layui-input-block">
                        <select name="releaser_id" lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <?php 
                            include "connect.sql.php";
                            $sql_1="SELECT * FROM artist ORDER BY artist_id ASC";
                            $res_1=mysqli_query($connect,$sql_1);
                            $row_num_1=mysqli_num_rows($res_1);/*获取查询的行数*/
                            if($row_num_1!=0)
                            {
                            for($a=1;$a<=$row_num_1;$a++)
                            {
                            $row_assoc_1=mysqli_fetch_assoc($res_1);
                            $artist_id=$row_assoc_1['artist_id'];
                            $artist_name=$row_assoc_1['artist_name'];
                            echo '<option value="'.$artist_id.'">'.$artist_name.'</option>
                            ';
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">发行厂牌</label>
                    <div class="layui-input-block">
                        <input type="text" name="label" placeholder="发行厂牌" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">发布时间</label>
				    <div class="layui-input-block">
                        <input type="date" name="time" placeholder="这首歌处于专辑的位置" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
				    </div>
			    </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">专辑封面</label>
                    <div class="layui-input-block">
                        <div class="ax-form-con">
                            <div class="ax-form-input">
                                <input onmouseout="document.getElementById('file-upload3').style.display='none';" id="file-view3" type="text" lay-search required  lay-verify="required">
                                <span onmouseover="document.getElementById('file-upload3').style.display='block';" class="ax-file-btn">选择</span>
                                <input onchange="document.getElementById('file-view3').value=this.value;" id="file-upload3" class="ax-input-file" type="file" name="file" lay-search required  lay-verify="required">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">描述</label>
				    <div class="layui-input-block">
					    <textarea placeholder="请输入内容" class="layui-textarea" name="description" lay-search required  lay-verify="required"></textarea>
				    </div>
			    </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="1">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_album.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">专辑ID</label>
                    <div class="layui-input-block">
                        <input type="text" name="album_id" placeholder="请输入序号（如果是选择修改专辑就必填）" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">专辑名</label>
                    <div class="layui-input-block">
                        <input type="text" name="album_name" placeholder="请输入标题" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">选择歌手</label>
                    <div class="layui-input-block">
                        <select name="releaser_id" lay-search required  lay-verify="required">
                            <option value="">请选择</option>
                            <?php 
                            include "connect.sql.php";
                            $sql_1="SELECT * FROM artist ORDER BY artist_id ASC";
                            $res_1=mysqli_query($connect,$sql_1);
                            $row_num_1=mysqli_num_rows($res_1);/*获取查询的行数*/
                            if($row_num_1!=0)
                            {
                            for($a=1;$a<=$row_num_1;$a++)
                            {
                            $row_assoc_1=mysqli_fetch_assoc($res_1);
                            $artist_id=$row_assoc_1['artist_id'];
                            $artist_name=$row_assoc_1['artist_name'];
                            echo '<option value="'.$artist_id.'">'.$artist_name.'</option>
                            ';
                            }
                            }
                            mysqli_close($connect);
                            ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">发行厂牌</label>
                    <div class="layui-input-block">
                        <input type="text" name="label" placeholder="发行厂牌" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">发布时间</label>
				    <div class="layui-input-block">
                        <input type="date" name="time" placeholder="这首歌处于专辑的位置" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
				    </div>
			    </div>
                <div class="layui-form-item layui-form-text">
				    <label class="layui-form-label">描述</label>
				    <div class="layui-input-block">
					    <textarea placeholder="请输入内容" class="layui-textarea" name="description" lay-search required  lay-verify="required"></textarea>
				    </div>
			    </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="2">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <form class="layui-form" action="manage/manage_album.php" enctype="multipart/form-data" method="post">
                <div class="layui-form-item">
                    <label class="layui-form-label">专辑ID</label>
                    <div class="layui-input-block">
                        <input type="text" name="album_id" placeholder="请输入序号（如果是选择修改专辑就必填）" autocomplete="off" class="layui-input" lay-search required  lay-verify="required">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit type="submit" name="select" value="3">立即提交</button>
                        <button type="reset" class="layui-btn layui-btn-primary">重置</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="layui-tab-item">
            <?php
            include "connect.sql.php";
            if(!empty($_SESSION['num']))
            {
            $user_num=$_SESSION['num'];
            $sql = "SELECT c.time,c.song_id,u.permission,u.num,u.name,comment,s.song_name,c.num
	        FROM comment c,usertable u,song s
	        where u.num='$user_num' and c.user_num=u.num and c.song_id=s.song_id";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            echo '
		    <div class="ax-comment">
		    <div class="ax-break-line"></div>
            '; 
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $comment_num=$row_assoc['num'];
            $song_id=$row_assoc['song_id'];
            $song_name=$row_assoc['song_name'];
            $time=$row_assoc['time'];
            $permission=$row_assoc['permission'];
            $num=$row_assoc['num'];
            $name=$row_assoc['name'];
            $comment=$row_assoc['comment'];
            echo '
		    <div class="ax-item">
		    <a href="##" class="ax-avatar" style="background-image: url(user/'.$user_num.'.jpg)"></a>
		    <div class="ax-text">
		    <div class="ax-row01 ax-row">
		    <div class="ax-col">
		    <a href="##" class="ax-name">'.$name.'</a>
		    </div>
		    </div>
		    <div class="ax-row02">
		    <span>'.$comment.'</span>
		    </div>
		    <div class="ax-row03 ax-row">
            <div class="ax-col">
            <span class="ax-time">'.$time.'<a href="song.php?id='.$song_id.'" class="ax-action ax-action-good">From 歌曲 '.$song_name.'</a></span>
            </div>
            <form action="manage/delect_comment.php" method="post">
            <button class="layui-btn layui-btn-danger layui-btn-sm" name="comment_id" value="'.$comment_num.'">删除</button>
            </form>
            </div>
		    </div>
		    </div>
		    <div class="ax-break-line"></div>                                                     
            ';
            }
		    echo '	
		    </div>
            ';
            }
            }
            mysqli_close($connect);
	        ?>

            <?php
            include "connect.sql.php";
            if(!empty($_SESSION['num']))
            {
            $user_num=$_SESSION['num'];
            $sql = "SELECT c.time,c.album_id,u.permission,u.num,u.name,comment,al.album_name,c.num
	        FROM comment c,usertable u,album al
	        where u.num='$user_num' and c.user_num=u.num and c.album_id=al.album_id";
            $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
            $row_num=mysqli_num_rows($res);
            if($row_num!=0)
            {
            echo '
			<div class="ax-comment">
			<div class="ax-break-line"></div>
            '; 
            for($i=1;$i<=$row_num;$i++)
            {
            $row_assoc=mysqli_fetch_assoc($res);
            $comment_num=$row_assoc['num'];
            $album_id=$row_assoc['album_id'];
            $album_name=$row_assoc['album_name'];
            $time=$row_assoc['time'];
            $permission=$row_assoc['permission'];
            $num=$row_assoc['num'];
            $name=$row_assoc['name'];
            $comment=$row_assoc['comment'];
            echo '
			<div class="ax-item">
			<a href="##" class="ax-avatar" style="background-image: url(user/'.$user_num.'.jpg)"></a>
		    <div class="ax-text">
			<div class="ax-row01 ax-row">
			<div class="ax-col">
			<a href="##" class="ax-name">'.$name.'</a>
			</div>
			</div>
			<div class="ax-row02">
		    <span>'.$comment.'</span>
			</div>
			<div class="ax-row03 ax-row">
            <div class="ax-col">
            <span class="ax-time">'.$time.'<a href="album.php?id='.$album_id.'" class="ax-action ax-action-good">From 专辑 '.$album_name.'</a></span>
            </div>
            <form action="manage/delect_comment.php" method="post">
            <button class="layui-btn layui-btn-danger layui-btn-sm" name="comment_id" value="'.$comment_num.'">删除</button>
            </form>
            </div>
		    </div>
			</div>
			<div class="ax-break-line"></div>                                                     
            ';
            }
			echo '	
			</div>
            ';
            }
            }
            mysqli_close($connect);
	        ?>
        </div>

    </div>
</div>