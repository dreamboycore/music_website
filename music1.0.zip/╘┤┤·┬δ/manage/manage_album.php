<?php
$select=$_POST["select"];
include "../connect.sql.php";

if($select==1)
{
if(!empty($_POST["album_name"])&&!empty($_POST["releaser_id"])&&
    !empty($_POST["label"])&&!empty($_POST["time"])&&
    !empty($_POST["description"])){
$album_name=$_POST["album_name"];
$releaser_id=$_POST["releaser_id"];
$label=$_POST["label"];
$time=$_POST["time"];
$description=$_POST["description"];
$sql="SELECT MAX(album_id) A FROM album";
$res=mysqli_query($connect,$sql);
$row_num=mysqli_num_rows($res);
if($row_num!=0) {
for($a=1;$a<=$row_num;$a++){
$row_assoc=mysqli_fetch_assoc($res);
$album_id=$row_assoc['A']+1;
$sql_write="INSERT INTO album (album_id,album_name,releaser_id,label,time,description) 
VALUES ($album_id,'$album_name',$releaser_id,'$label','$time','$description')";
$res=mysqli_query($connect,$sql_write);
if($res){
    $cover_folder=intval(($album_id-1)/100)+1;
    $file=$_FILES["file"];
    move_uploaded_file($file['tmp_name'],"../cover/".$cover_folder."/".$album_id.".jpg");
    header("location:../manage.php");
}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}}}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

elseif($select==2)
{
if(!empty($_POST["album_id"])&&!empty($_POST["album_name"])&&
    !empty($_POST["releaser_id"])&&!empty($_POST["label"])&&
    !empty($_POST["time"])&&!empty($_POST["description"])){
$album_id=$_POST["album_id"];
$album_name=$_POST["album_name"];
$releaser_id=$_POST["releaser_id"];
$label=$_POST["label"];
$time=$_POST["time"];
$description=$_POST["description"];
$sql_write="UPDATE album SET album_name='$album_name',releaser_id='$releaser_id',label='$label',
time='$time',description='$description' WHERE album_id='$album_id'
";
$res=mysqli_query($connect,$sql_write);
if($res){header("location:../manage.php");}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

elseif($select==3)
{
if(!empty($_POST["album_id"])){
$album_id=$_POST["album_id"];
$sql_write="DELETE FROM album WHERE album_id='$album_id'";
$res=mysqli_query($connect,$sql_write);
if($res){
    $cover_folder=intval(($album_id-1)/100)+1;
    $file="../cover/".$cover_folder."/".$album_id.".jpg";
    unlink($file);
    header("location:../manage.php");
}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

else{echo '<script language="JavaScript">;alert("错误");location.href="../manage.php";</script>';}




mysqli_close($connect);

?>