<?php
$select=$_POST["select"];
include "../connect.sql.php";

if($select==1)
{
if(!empty($_POST["artist_name"])&&!empty($_POST["country"])&&
    !empty($_POST["description"])&&!empty($_POST["type"])){
$artist_name=$_POST["artist_name"];
$country=$_POST["country"];
$description=$_POST["description"];
$type=$_POST["type"];
$sql="SELECT MAX(artist_id) A FROM artist";
$res=mysqli_query($connect,$sql);
$row_num=mysqli_num_rows($res);
if($row_num!=0) {
for($a=1;$a<=$row_num;$a++){
$row_assoc=mysqli_fetch_assoc($res);
$artist_id=$row_assoc['A']+1;
$sql_write="INSERT INTO artist (artist_id,artist_name,country,description,type) 
VALUES ($artist_id,'$artist_name','$country','$description','$type')";
$res=mysqli_query($connect,$sql_write);
if($res){header("location:../manage.php");}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}}}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

elseif($select==2)
{
if(!empty($_POST["artist_id"])&&!empty($_POST["artist_name"])&&
    !empty($_POST["country"])&&!empty($_POST["description"])&&
    !empty($_POST["type"])){
$artist_id=$_POST["artist_id"];
$artist_name=$_POST["artist_name"];
$country=$_POST["country"];
$description=$_POST["description"];
$type=$_POST["type"];
$sql_write="UPDATE artist SET artist_name='$artist_name',country='$country',
description='$description',type='$type' WHERE artist_id='$artist_id'";
$res=mysqli_query($connect,$sql_write);
if($res){header("location:../manage.php");}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

elseif($select==3)
{
if(!empty($_POST["artist_id"])){
$artist_id=$_POST["artist_id"];
$sql_write_1="DELETE FROM artist WHERE artist_id='$artist_id'";
$sql_write_2="DELETE FROM album WHERE releaser_id='$artist_id'";
$sql_write_3="DELETE FROM song WHERE artist_id='$artist_id'";
$res_1=mysqli_query($connect,$sql_write_1);
$res_2=mysqli_query($connect,$sql_write_2);
$res_3=mysqli_query($connect,$sql_write_3);
if($res_1&&$res_2&&$res_3)
{
    header("location:../manage.php");
}
else{echo '<script language="JavaScript">;alert("未知错误");location.href="../manage.php";</script>';}
}
else{echo '<script language="JavaScript">;alert("数据不齐");location.href="../manage.php";</script>';}
}

else{echo '<script language="JavaScript">;alert("错误");location.href="../manage.php";</script>';}

mysqli_close($connect);

?>