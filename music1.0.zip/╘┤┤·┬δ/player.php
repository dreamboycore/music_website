<script type='text/javascript'>
//播放列表
const ap = new APlayer({
    element: document.getElementById('aplayer'),
    bottom: true,
    listFolded:true,
    lrcType: 0,
    audio: [
        <?php 
        include "connect.sql.php";
        if(!empty($_SESSION["permission"]))
        {
        for($i=0;$i<$_SESSION["play_num"];$i++)
        { 
        $save=$_SESSION["play_song"][$i];
        $sql="SELECT * FROM song s,artist a WHERE song_id='$save' AND s.artist_id=a.artist_id";
        $res=mysqli_query($connect,$sql);
        $row=mysqli_num_rows($res);//获取查询的行数
        if($row!=0) 
        {
        $row_assoc=mysqli_fetch_assoc($res);
        $song_id=$row_assoc['song_id'];
        $song_name=$row_assoc['song_name'];
        $artist_name=$row_assoc['artist_name'];
        $album_id=$row_assoc['album_id'];
        $cover_folder=intval(($album_id-1)/100)+1;
        $audio_folder=intval(($song_id-1)/100)+1;
        echo "
        {
        name:'".$song_name."',
        artist:'".$artist_name."',
        url:'audio/".$audio_folder."/".$song_id.".mp3',
        cover:'cover/".$cover_folder."/".$album_id.".jpg',
        href:'song.php?id=".$song_id."',
        },
        ";
        }
        }
        }
        mysqli_close($connect);
        ?>
    ]
});


<?php 
if(!empty($_SESSION["permission"])) 
{
    echo 'var list = new Array();';

    echo 'var w='.$_SESSION["play_num"].';';
    if($_SESSION['play_num']!=0)
    {
    for($i=0;$i<$_SESSION['play_num'];$i++)
    {
        echo 'list['.$i.'] = '.$_SESSION["play_song"][$i].';';
    }        
    }

}
else 
{
    echo "
    var w=0;var list = new Array();
    layui.use('layer', function(){
        var layer = layui.layer;
        layer.msg('登录有更好的体验');
    })
    ";
}
?>
//加入歌曲
<?php
include "connect.sql.php";
$sql = "select * from song s,artist a WHERE s.artist_id=a.artist_id";
$res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
$row_num=mysqli_num_rows($res);
if($row_num!=0){
for($i=1;$i<=$row_num;$i++){
    $row_assoc=mysqli_fetch_assoc($res);
    $song_id=$row_assoc['song_id'];
    $song_name=$row_assoc['song_name'];
    $artist_name=$row_assoc['artist_name'];
    $album_id=$row_assoc['album_id'];
    $cover_folder=intval(($album_id-1)/100)+1;
    $audio_folder=intval(($song_id-1)/100)+1;
    echo "$('#id-".$song_id."').click(function () {
    if(!list.includes(".$song_id.")){
    ap.list.add([{
    name:'".$song_name."',artist:'".$artist_name."',
    url:'audio/".$audio_folder."/".$song_id.".mp3',cover:'cover/".$cover_folder."/".$album_id.".jpg',
    href:'song.php?id=".$song_id."',}]);list[w] = ".$song_id.";w=w+1;
    $.ajax({
    type:'GET',
    url:'button/save.php?id=".$song_id."',
    success:function(){
        layui.use('layer', function(){
        var layer = layui.layer;
        layer.msg('第'+w+'首歌曲：“".$artist_name." - ".$song_name."”<br>成功加入列表');});},
    error:function(){alert('错误');}});}else{
    layui.use('layer', function(){
        var layer = layui.layer;
        layer.msg('已添加<br>“".$artist_name." - ".$song_name."”');});}});";}}
mysqli_close($connect);
?>

$('#clear').click(function () {
    ap.list.clear();
    var w=0;
    $.ajax({
            type:'GET',
            url:'button/clear.php',
            success:function()
            {
                layui.use('layer', function(){
                    var layer = layui.layer;
                    layer.msg('成功');
                });
            },
            error:function(){alert('错误');}
        });
});

</script>

<script>
$("button[name='hot']").click(function () {
    var id = $(this).attr("value");
    <?php 
    if(!empty($_SESSION["permission"])) 
    {
    echo '
    $.ajax({
        type:\'GET\',
        url:\'button/hot.php?song_id=\'+id,
        success:function()
        {
            layui.use(\'layer\', function(){
                var layer = layui.layer;
                layer.msg(\'你为序号为\'+id+\'的歌曲点赞成功，谢谢你的支持\'); 
            });
        },
        error:function(){alert(\'错误\');}
    });
    ';
    }
    else {echo 'alert(\'登录再点赞吧\');';}
    ?>
});
</script>