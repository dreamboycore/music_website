<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="layui/css/layui.css">
    <link href="axui/css/ax.css" rel="stylesheet" type="text/css" >
    <link href="axui/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?> 

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">
    
<div class="layui-row layui-col-space20">
    <div class="layui-col-sm3 layui-col-md4 layui-col-lg2">
        <ul class="layui-nav layui-nav-tree layui-bg-green" lay-filter="" style="width:100%;">
        <li class="layui-nav-item"><a href="topist.php">梦音乐新歌榜</a></li>
        <li class="layui-nav-item"><a href="topist.php?id=0">梦音乐总榜</a></li>
        <li class="layui-nav-item layui-nav-itemed">
            <a href="javascript:;">梦音乐中国榜</a>
            <dl class="layui-nav-child">
            <dd><a href="topist.php?id=1">国语排行榜</a></dd>
            <dd><a href="topist.php?id=2">闽南语排行榜</a></dd>
            <dd><a href="topist.php?id=3">粤语排行榜</a></dd>
            <dd><a href="topist.php?id=4">其他方言排行榜</a></dd>
            </dl>
        </li>
        <li class="layui-nav-item layui-nav-itemed">
            <a href="javascript:;">梦音乐国际榜</a>
            <dl class="layui-nav-child">
            <dd><a href="topist.php?id=5">英语排行榜</a></dd>
            <dd><a href="topist.php?id=6">日语排行榜</a></dd>
            <dd><a href="topist.php?id=7">其他语种排行榜</a></dd>
            </dl>
        </li>
        </ul>
    </div>

    <div class="layui-col-sm9 layui-col-md8 layui-col-lg10">
        <div class="layui-row layui-col-space10">
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <?php
                $language=isset($_GET['id'])?$_GET['id']:100;
                switch($language)
                {
                case 0:echo '<h2>梦音乐总榜<h2><br>';break;
                case 1:echo '<h2>国语排行榜<h2><br>';break;
                case 2:echo '<h2>闽南语排行榜<h2><br>';break;
                case 3:echo '<h2>粤语排行榜<h2><br>';break;
                case 4:echo '<h2>其他方言排行榜<h2><br>';break;
                case 5:echo '<h2>英语排行榜<h2><br>';break;
                case 6:echo '<h2>日语排行榜<h2><br>';break;
                case 7:echo '<h2>其他语种排行榜<h2><br>';break;
                case 100:echo '<h2>梦音乐新歌榜<h2><br>';break;
                default:echo '<h2>禁止盗链接<h2><br>';
                }
                ?>
            </div>
            <div class="layui-col-sm12 layui-col-md12 layui-col-lg12">
                <table class="layui-table" lay-size="sm" style="margin: 0 auto;">
                    <colgroup>
                    <col>
                    <col>
                    <col>
                    <col width="200">
                    </colgroup>
                    <thead>
                    <tr>
                    <th>排名</th>
                    <th>标题</th>
                    <th>歌手</th>
                    <th>选项</th>
                    </tr> 
                    </thead>
                    <tbody>
                    <?php
                    $language=isset($_GET['id'])?$_GET['id']:100;
                    include "connect.sql.php";
                    if($language==0)
                    {$sql = "SELECT s.song_id,s.song_name,a.artist_name,s.served,s.artist_id,s.album_id 
                    FROM song s,artist a WHERE s.artist_id=a.artist_id ORDER BY hot DESC";}
                    elseif($language>=1&&$language<=7)
                    {$sql = "SELECT s.song_id,s.song_name,a.artist_name,s.served,s.artist_id,s.album_id 
                    FROM song s,artist a WHERE s.artist_id=a.artist_id AND language='$language' ORDER BY hot DESC";}
                    else{$sql = "SELECT s.song_id,s.song_name,a.artist_name,s.served,s.artist_id,s.album_id
                    FROM song s,artist a WHERE s.artist_id=a.artist_id ORDER BY s.song_id DESC";}
                    $res=mysqli_query($connect,$sql); //$conn是connect.php中的连接
                    $row_num=mysqli_num_rows($res);
                    if($row_num!=0)
                    {
                    if($row_num>10){$row_num=10;}
                    for($i=1;$i<=$row_num;$i++)
                    {
                    $row_assoc=mysqli_fetch_assoc($res);
                    $song_id=$row_assoc['song_id'];
                    $song_name=$row_assoc['song_name'];
                    $artist_id=$row_assoc['artist_id'];
                    $artist_name=$row_assoc['artist_name'];
                    $served=$row_assoc['served'];
                    $album_id=$row_assoc['album_id'];
                    $audio_folder=intval(($song_id-1)/100)+1;
                    echo '
                    <tr>
                    <td>'.$i.'</td>
                    <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
                    <td><a href="artist.php?id='.$artist_id.'">'.$artist_name.'</a></td>
                    <td>
                    <button class="layui-btn layui-btn-warm layui-btn-sm" href="##" id="id-'.$song_id.'">加入</button>
                    <button class="layui-btn layui-btn-danger layui-btn-sm" name="hot" value="'.$song_id.'">点赞</button>
                    ';
if(!empty($_SESSION['num']))
{
if(($_SESSION['permission']==1)||($_SESSION['permission']==2&&$served==2))
{
echo '<button class="layui-btn layui-btn-sm"><a href="audio/'.$audio_folder.'/'.$song_id.'.mp3" download="'.$artist_name.' - '.$song_name.'.mp3">下载</a></button>';
}
else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
}
else{echo '<button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>';}
                    echo '
                    </td>
                    </tr>
                    ';
                    }
                    }
                    mysqli_close($connect);
                    ?>
                    </tbody>
                </table>   
            </div> 
        </div>    
    </div> 
</div>

</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="layui/layui.js"></script>
<script src="axui/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="axui/js/ax.min.js" type="text/javascript"></script>
<script src="axui/APlayer.min.js"></script>

<?php include "player.php";?>

<?php include "js.php"; ?>

</body> 
</html> 