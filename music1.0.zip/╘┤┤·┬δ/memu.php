<ul class="layui-nav layui-bg-green" lay-filter="">
<li class="layui-nav-item"><a href="index.php">网站首页</a></li>

<li class="layui-nav-item"><a href="http://www.dreamboycore-official.com" target="_blank">开发者的个人网页</a></li>
</ul>
<ul class="layui-nav layui-bg-green layui-layout-right">
    <?php include 'inout/inout.php';?>
</ul>

<div class="layui-bg-blue">
    <div class="layui-container">
        <div class="ax-grid">
            <ul class="ax-menu ax-menu-light ax-grid-inner" id="menu01">
            <li class="ax-col-3-avg ax-grid-block">
                <a href="index.php"><span class="ax-name">网站首页</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
            </li>
            <li class="ax-col-3-avg ax-grid-block">
                <a href="topist.php"><span class="ax-name">排行榜单</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
            </li>
            <li class="ax-col-3-avg ax-grid-block">
                <a href="search.php"><span class="ax-name">快速搜索</span><span class="ax-arrow ax-iconfont ax-icon-right"></span></a>
            </li>
            </ul>
        </div>
    </div>
</div>


<div class="ax-window" id="win00" data-size="full">
    <div class="ax-window-overlay"></div>
    <div class="ax-window-contain">
        <a href="##" class="ax-window-close"><i class="ax-iconfont ax-icon-close"></i></a>
        <div class="ax-window-content">
            <div class="ax-break-xl"></div>
            <div class="ax-padding">
            <?php 
            if(!empty($_SESSION["permission"]))
            {
                echo '
                <button class="layui-btn layui-btn-warm layui-btn-sm" href="##" id="clear">一键清空列表</button>
                <br><br>
				<table class="layui-table" lay-size="sm" style="margin: 0 auto;">
                    <colgroup> 
                    <col>
                    <col>
                    <col>
                    <col width="60">
                    </colgroup>
                    <thead>
                    <tr>
                    <th>序号</th>
                    <th>标题</th>
                    <th>歌手</th>
                    <th>选项</th>
                    </tr> 
                    </thead>
                    <tbody>';
                    include "connect.sql.php";
                    for($play_num=0;$play_num<$_SESSION['play_num'];$play_num++)
                    {
                    $part=$play_num+1;
                    $play_song=$_SESSION['play_song'][$play_num];
                    $sql = "SELECT * FROM song s,artist a WHERE song_id='$play_song' AND s.artist_id=a.artist_id";
                    $res=mysqli_query($connect,$sql);
                    $row_num=mysqli_num_rows($res);
                    if($row_num!=0)
                    {
                    for($i=1;$i<=$row_num;$i++)
                    {
                    $row_assoc=mysqli_fetch_assoc($res);
                    $song_id=$row_assoc['song_id'];
                    $song_name=$row_assoc['song_name'];
                    $artist_name=$row_assoc['artist_name'];
                    echo '
                    <tr>
                    <td>'.$part.'</td>
                    <td><a href="song.php?id='.$song_id.'">'.$song_name.'</a></td>
                    <td>'.$artist_name.'</td>
                    <td>
                    <button class="layui-btn layui-btn-disabled layui-btn-sm">下载</button>
                    </td>
                    </tr>
                    ';
                    }
                    }
                    }
                    mysqli_close($connect);
                    echo '
                    </tbody>
                </table>
                <br>
                <br>
                ';
                }
                else{echo '登录后才能体验完整版的播放列表功能';}
            ?>            
            </div>
        </div>
        <div class="ax-padding ax-window-operate">
            <div class="ax-row">
                <div class="ax-col"></div>
                <div class="ax-btns">
                    <a href="##" class="ax-btn ax-ignore ax-window-close">取消</a>
                    <a href="##" class="ax-btn ax-primary">确定</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="ax-window" id="win01">
    <div class="ax-window-overlay"></div>
    <div class="ax-window-contain">
        <a href="##" class="ax-window-close"><i class="ax-iconfont ax-icon-close"></i></a>
        <div class="ax-window-content">
            <div class="ax-break-xl"></div>
            <div class="ax-padding">
				<form class="layui-form" action="inout/login.php" method="post">
					<div class="layui-form-item"><h2>请登录</h2></div>
					<div class="layui-form-item">
						<label class="layui-form-label">登录账户</label>
						<div class="layui-input-block">
							<input type="text" name="id" required lay-verify="required" placeholder="请输入账户名" autocomplete="off" class="layui-input">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">登录密码</label>
						<div class="layui-input-inline">
							<input type="password" name="pw" required lay-verify="required" placeholder="请输入密码" autocomplete="off" class="layui-input">
						</div>
						<div class="layui-form-mid layui-word-aux">请不要忘记密码</div>
					</div>
					<div class="layui-form-item">
						<div class="layui-input-block">
							<button class="layui-btn" type="submit" lay-submit>登录</button>
							<button type="reset" class="layui-btn layui-btn-primary">重置</button>
						</div>
					</div>
				</form>	
            </div>
        </div>
        <div class="ax-padding ax-window-operate">
            <div class="ax-row">
                <div class="ax-col"></div>
                <div class="ax-btns">
                    <a href="##" class="ax-btn ax-ignore ax-window-close">取消</a>
                    <a href="##" class="ax-btn ax-primary">确定</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="ax-window" id="win02">
    <div class="ax-window-overlay"></div>
    <div class="ax-window-contain">
        <a href="##" class="ax-window-close"><i class="ax-iconfont ax-icon-close"></i></a>
        <div class="ax-window-content">
            <div class="ax-break-xl"></div>
            <div class="ax-padding">
				<form class="layui-form" action="inout/register.php" method="post" enctype="multipart/form-data">
					<div class="layui-form-item"><h2>请注册</h2></div>
					<div class="layui-form-item">
						<label class="layui-form-label">登录账户</label>
						<div class="layui-input-block">
							<input type="text" name="id" required lay-verify="required" placeholder="请输入账户名" autocomplete="off" class="layui-input">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">登录密码</label>
						<div class="layui-input-inline">
							<input type="password" name="pw" required lay-verify="required" placeholder="请输入密码" autocomplete="off" class="layui-input">
						</div>
						<div class="layui-form-mid layui-word-aux">请不要忘记密码</div>
					</div>
                    <div class="layui-form-item">
						<label class="layui-form-label">登录昵称</label>
						<div class="layui-input-inline">
							<input type="text" name="name" required lay-verify="required" placeholder="请输入昵称" autocomplete="off" class="layui-input">
						</div>
						<div class="layui-form-mid layui-word-aux">请不要忘记密码</div>
					</div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">上传文件</label>
                        <div class="layui-input-block">
                            <div class="ax-form-con">
                                <div class="ax-form-input">
                                    <input onmouseout="document.getElementById('file-upload').style.display='none';" id="file-view" type="text" required lay-verify="required">
                                    <span onmouseover="document.getElementById('file-upload').style.display='block';" class="ax-file-btn">选择</span>
                                    <input onchange="document.getElementById('file-view').value=this.value;" id="file-upload" class="ax-input-file" type="file" name="file" required lay-verify="required">
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="layui-form-item">
						<div class="layui-input-block">
							<button class="layui-btn" type="submit" lay-submit>注册</button>
							<button type="reset" class="layui-btn layui-btn-primary">重置</button>
						</div>
					</div>
				</form>	
            </div>
        </div>
        <div class="ax-padding ax-window-operate">
            <div class="ax-row">
                <div class="ax-col"></div>
                <div class="ax-btns">
                    <a href="##" class="ax-btn ax-ignore ax-window-close">取消</a>
                    <a href="##" class="ax-btn ax-primary">确定</a>
                </div>
            </div>
        </div>
    </div>
</div>
