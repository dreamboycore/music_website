<?php
$connect = mysqli_connect("localhost","root","root","music");
?>