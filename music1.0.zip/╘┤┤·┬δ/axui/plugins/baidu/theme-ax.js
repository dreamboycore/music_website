
(function (root, factory) {
    if (typeof define === 'function' && define.amd) {
        // AMD. Register as an anonymous module.
        define(['exports', 'echarts'], factory);
    } else if (typeof exports === 'object' && typeof exports.nodeName !== 'string') {
        // CommonJS
        factory(exports, require('echarts'));
    } else {
        // Browser globals
        factory({}, root.echarts);
    }
}(this, function (exports, echarts) {
    var log = function (msg) {
        if (typeof console !== 'undefined') {
            console && console.error && console.error(msg);
        }
    };
    if (!echarts) {
        log('ECharts is not Loaded');
        return;
    }
    echarts.registerTheme('theme-ax', {
        "color": [
            "#198cff",
            "#ff8400",
            "#475b66",
            "#6619ff",
            "#41a358",
            "#ffc107",
            "#dc3545",
            "#bda29a",
            "#6e7074",
            "#546570",
            "#c4ccd3"
        ],
        "backgroundColor": "rgba(0, 0, 0, 0)",
        "textStyle": {},
        "title": {
            "textStyle": {
                "color": "#333333"
            },
            "subtextStyle": {
                "color": "#aaaaaa"
            }
        },
        "line": {
            "itemStyle": {
                "normal": {
                    "borderWidth": "2"
                }
            },
            "lineStyle": {
                "normal": {
                    "width": "2"
                }
            },
            "symbolSize": "6",
            "symbol": "emptyCircle",
            "smooth": true
        },
        "radar": {
            "itemStyle": {
                "normal": {
                    "borderWidth": "2"
                }
            },
            "lineStyle": {
                "normal": {
                    "width": "2"
                }
            },
            "symbolSize": "6",
            "symbol": "emptyCircle",
            "smooth": true
        },
        "bar": {
            "itemStyle": {
                "normal": {
                    "barBorderWidth": 0,
                    "barBorderColor": "#eeeeee"
                },
                "emphasis": {
                    "barBorderWidth": 0,
                    "barBorderColor": "#eeeeee"
                }
            }
        },
        "pie": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "scatter": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "boxplot": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "parallel": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "sankey": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "funnel": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "gauge": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                },
                "emphasis": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            }
        },
        "candlestick": {
            "itemStyle": {
                "normal": {
                    "color": "#dc3545",
                    "color0": "#475b66",
                    "borderColor": "#dc3545",
                    "borderColor0": "#475b66",
                    "borderWidth": 1
                }
            }
        },
        "graph": {
            "itemStyle": {
                "normal": {
                    "borderWidth": 0,
                    "borderColor": "#eeeeee"
                }
            },
            "lineStyle": {
                "normal": {
                    "width": "1",
                    "color": "#cccccc"
                }
            },
            "symbolSize": "6",
            "symbol": "emptyCircle",
            "smooth": true,
            "color": [
                "#198cff",
                "#ff8400",
                "#475b66",
                "#6619ff",
                "#41a358",
                "#ffc107",
                "#dc3545",
                "#bda29a",
                "#6e7074",
                "#546570",
                "#c4ccd3"
            ],
            "label": {
                "normal": {
                    "textStyle": {
                        "color": "#ffffff"
                    }
                }
            }
        },
        "map": {
            "itemStyle": {
                "normal": {
                    "areaColor": "#eee",
                    "borderColor": "#444",
                    "borderWidth": 0.5
                },
                "emphasis": {
                    "areaColor": "rgba(255,215,0,0.8)",
                    "borderColor": "#444",
                    "borderWidth": 1
                }
            },
            "label": {
                "normal": {
                    "textStyle": {
                        "color": "#000"
                    }
                },
                "emphasis": {
                    "textStyle": {
                        "color": "rgb(100,0,0)"
                    }
                }
            }
        },
        "geo": {
            "itemStyle": {
                "normal": {
                    "areaColor": "#eee",
                    "borderColor": "#444",
                    "borderWidth": 0.5
                },
                "emphasis": {
                    "areaColor": "rgba(255,215,0,0.8)",
                    "borderColor": "#444",
                    "borderWidth": 1
                }
            },
            "label": {
                "normal": {
                    "textStyle": {
                        "color": "#000"
                    }
                },
                "emphasis": {
                    "textStyle": {
                        "color": "rgb(100,0,0)"
                    }
                }
            }
        },
        "categoryAxis": {
            "axisLine": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisTick": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisLabel": {
                "show": true,
                "textStyle": {
                    "color": "#666666"
                }
            },
            "splitLine": {
                "show": true,
                "lineStyle": {
                    "color": [
                        "#ebebeb"
                    ]
                }
            },
            "splitArea": {
                "show": true,
                "areaStyle": {
                    "color": [
                        "rgba(250,250,250,0.3)",
                        "rgba(200,200,200,0.1)"
                    ]
                }
            }
        },
        "valueAxis": {
            "axisLine": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisTick": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisLabel": {
                "show": true,
                "textStyle": {
                    "color": "#666666"
                }
            },
            "splitLine": {
                "show": true,
                "lineStyle": {
                    "color": [
                        "#ebebeb"
                    ]
                }
            },
            "splitArea": {
                "show": true,
                "areaStyle": {
                    "color": [
                        "rgba(250,250,250,0.3)",
                        "rgba(200,200,200,0.1)"
                    ]
                }
            }
        },
        "logAxis": {
            "axisLine": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisTick": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisLabel": {
                "show": true,
                "textStyle": {
                    "color": "#666666"
                }
            },
            "splitLine": {
                "show": true,
                "lineStyle": {
                    "color": [
                        "#ebebeb"
                    ]
                }
            },
            "splitArea": {
                "show": true,
                "areaStyle": {
                    "color": [
                        "rgba(250,250,250,0.3)",
                        "rgba(200,200,200,0.1)"
                    ]
                }
            }
        },
        "timeAxis": {
            "axisLine": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisTick": {
                "show": true,
                "lineStyle": {
                    "color": "#cccccc"
                }
            },
            "axisLabel": {
                "show": true,
                "textStyle": {
                    "color": "#666666"
                }
            },
            "splitLine": {
                "show": true,
                "lineStyle": {
                    "color": [
                        "#ebebeb"
                    ]
                }
            },
            "splitArea": {
                "show": true,
                "areaStyle": {
                    "color": [
                        "rgba(250,250,250,0.3)",
                        "rgba(200,200,200,0.1)"
                    ]
                }
            }
        },
        "toolbox": {
            "iconStyle": {
                "normal": {
                    "borderColor": "#aaaaaa"
                },
                "emphasis": {
                    "borderColor": "#666"
                }
            }
        },
        "legend": {
            "textStyle": {
                "color": "#666666"
            }
        },
        "tooltip": {
            "axisPointer": {
                "lineStyle": {
                    "color": "#b3b3b3",
                    "width": 1
                },
                "crossStyle": {
                    "color": "#b3b3b3",
                    "width": 1
                }
            }
        },
        "timeline": {
            "lineStyle": {
                "color": "#b3b3b3",
                "width": 1
            },
            "itemStyle": {
                "normal": {
                    "color": "#b3b3b3",
                    "borderWidth": 1
                },
                "emphasis": {
                    "color": "#666666"
                }
            },
            "controlStyle": {
                "normal": {
                    "color": "#b3b3b3",
                    "borderColor": "#b3b3b3",
                    "borderWidth": 0.5
                },
                "emphasis": {
                    "color": "#b3b3b3",
                    "borderColor": "#b3b3b3",
                    "borderWidth": 0.5
                }
            },
            "checkpointStyle": {
                "color": "#198cff",
                "borderColor": "rgba(217,236,255,1)"
            },
            "label": {
                "normal": {
                    "textStyle": {
                        "color": "#666666"
                    }
                },
                "emphasis": {
                    "textStyle": {
                        "color": "#666666"
                    }
                }
            }
        },
        "visualMap": {
            "color": [
                "#dc3545",
                "#ffa543",
                "#ffe598"
            ]
        },
        "dataZoom": {
            "backgroundColor": "rgba(255,255,255,1)",
            "dataBackgroundColor": "rgba(235,235,235,1)",
            "fillerColor": "rgba(0,0,0,0.06)",
            "handleColor": "#b3b3b3",
            "handleSize": "100%",
            "textStyle": {
                "color": "#666666"
            }
        },
        "markPoint": {
            "label": {
                "normal": {
                    "textStyle": {
                        "color": "#ffffff"
                    }
                },
                "emphasis": {
                    "textStyle": {
                        "color": "#ffffff"
                    }
                }
            }
        }
    });
}));
