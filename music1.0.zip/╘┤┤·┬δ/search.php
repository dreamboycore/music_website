<!DOCTYPE html>
<html>
<head>
    <title>在线音乐播放器</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="layui/css/layui.css">
    <link href="axui/css/ax.css" rel="stylesheet" type="text/css" >
    <link href="axui/css/ax-response.css" rel="stylesheet" type="text/css" >
</head>
<body>

<?php include "memu.php"; ?> 

<div class="layui-bg-gray">
<div class="layui-container">
<div style="background-color:#FFFFFF">
<div style="border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;padding:15px">

<form class="layui-form" action="result.php">
    <div class="layui-form-item">
        <label class="layui-form-label">功能选择</label>
        <div class="layui-input-block">
            <select name="select" lay-search required  lay-verify="required">
            <option value="">请选择</option>
            <option value="1">歌曲搜索</option>
            <option value="2">专辑搜索</option>
            <option value="3">歌手搜索</option>
            </select>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">搜索框</label>
        <div class="layui-input-block">
            <input type="text" name="str" placeholder="必须填的" autocomplete="off" class="layui-input"  lay-search required  lay-verify="required">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            <button type="reset" class="layui-btn layui-btn-primary">重置</button>
        </div>
    </div>
</form>
 


</div>
</div>
</div>
</div>

<?php include "footer.php"; ?>

<div class="ax-footer">
	<div id="aplayer" class="ax-aplayer"></div>
</div>

<script src="layui/layui.js"></script>
<script src="axui/js/jquery-1.10.2.min.js" type="text/javascript"></script>
<script src="axui/js/ax.min.js" type="text/javascript"></script>
<script src="axui/APlayer.min.js"></script>

<?php include "player.php";?>

<?php include "js.php"; ?>

</body> 
</html> 